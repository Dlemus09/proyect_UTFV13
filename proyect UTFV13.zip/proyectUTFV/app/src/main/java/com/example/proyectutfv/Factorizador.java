package com.example.proyectutfv;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Factorizador {


    class Polinomio {


        private String entrada;
        private String[] polinomios;
        private List<String> terminos = separaTerminos(entrada);


        Polinomio(String entrada) {
            this.entrada = entrada;
        }

        public int cuentaTerminos() {
            String delimiter = "[+-]";
            polinomios = entrada.split(delimiter);
            int count = cuentaSaltos(entrada, delimiter);
            return count;
        }//fin cuentaterminos

        private int cuentaSaltos(String s, String d) {
            String parts[] = s.split(d);
            return parts.length;
        }

        public List<String> separaTerminos(String entrada) {
            Pattern pattern = Pattern.compile("[+-]?[^+-]+");
            Matcher matcher = pattern.matcher(entrada);
            while (matcher.find()){
                String termino = matcher.group().trim();
                if(!termino.isEmpty()){
                    terminos.add(termino);
                }
            }
            return terminos;
        }
        /*
        private enum tipo {
            monomio,
            binomio,
            trinomio,
            poli
        }

         */


    }


    //define terminos sencillos sin punto decimal
    class Termino {
        private int coeficiente;
        private char variable;
        private int exponente;
        private int grado;

        Termino(int coeficiente, char variable, int exponente) {
            this.coeficiente = coeficiente;
            this.variable = variable;
            this.exponente = exponente;
            grado = exponente;
        }

        public int getCoeficiente() {
            return coeficiente;
        }

        public char getVariable() {
            return variable;
        }

        public int getExponente() {
            return exponente;
        }

        public int getGrado() {
            return grado;
        }

        public String getTermino() {
            return coeficiente + variable + "^" + exponente;
        }

    }//fin class Termino
}

