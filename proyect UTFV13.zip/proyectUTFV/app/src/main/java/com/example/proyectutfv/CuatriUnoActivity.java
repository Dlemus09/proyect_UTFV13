package com.example.proyectutfv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class CuatriUnoActivity extends AppCompatActivity {
    ListView listaCuatriUno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuatri_uno);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.PhotoView), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listaCuatriUno = findViewById(R.id.listcuatriuno);
        listaCuatriUno.setAdapter(creaAdaptador());

        listaCuatriUno.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((CustomObject) parent.getItemAtPosition(position)).getTitulo();

                if ("Matematicas".equals(selectedItem)) {
                    Intent intent = new Intent(CuatriUnoActivity.this, Listamate.class);
                    startActivity(intent);
                } else if ("programacion".equals(selectedItem)) {
                    Intent intent= new Intent(CuatriUnoActivity.this, ListaProgramacion.class);
                     startActivity(intent);
                } else {
                    Toast.makeText(CuatriUnoActivity.this, "En construcción", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public CustomAdapter creaAdaptador() {
        String[] listaUno = {
                "Matematicas",
                "programacion",
                "IOT",
                "Web",
                "otras"
        };

        // Lista de imágenes ajustada para que coincida con listaUno
        int[] imageArray = {
                R.drawable.dragoncastillo,
                R.drawable.dragoncitolector,
                R.drawable.dragoncitolibro,
                R.drawable.dragoncitolibros,
        };

        List<CustomObject> objetosVista = new ArrayList<>();
        for (int i = 0; i < listaUno.length; i++) {
            objetosVista.add(new CustomObject(listaUno[i], imageArray[i % imageArray.length]));
        }

        return new CustomAdapter(this, objetosVista);
}
}