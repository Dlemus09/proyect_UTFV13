package com.example.proyectutfv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class ListaProgramacion extends AppCompatActivity {
    ListView listaPro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_programacion);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.PhotoView), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listaPro = findViewById(R.id.listaPro);
        listaPro.setAdapter(creaAdaptador());

        listaPro.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((CustomObject) parent.getItemAtPosition(position)).getTitulo();

                if ("Diccionario".equals(selectedItem)) {
                    //Intent intent = new Intent(ListaProgramacion.this, Listamate.class);
                    //startActivity(intent);
                    Toast.makeText(ListaProgramacion.this, "En construcción dicc", Toast.LENGTH_SHORT).show();
                } else if ("CalculaResistencia".equals(selectedItem)) {
                    Intent intent = new Intent(ListaProgramacion.this, ResistenciaActivity.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(ListaProgramacion.this, "En construcción", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public CustomAdapter creaAdaptador() {
        String[] listaUno = {
                "Diccionario",
                "CalculaResistencia",
                "otros"
        };

        // Lista de imágenes ajustada para que coincida con listaUno
        int[] imageArray = {
                R.drawable.dragoncastillo,
                R.drawable.dragoncitolector,
                R.drawable.dragoncitolibro,
                R.drawable.dragoncitolibros,
        };

        List<CustomObject> objetosVista = new ArrayList<>();
        for (int i = 0; i < listaUno.length; i++) {
            objetosVista.add(new CustomObject(listaUno[i], imageArray[i % imageArray.length]));
        }

        return new CustomAdapter(this, objetosVista);
    }
}