package com.example.proyectutfv;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;

public class ResistenciaActivity extends AppCompatActivity {
    private TextView txtvb1, txtvb2, txtvb3, txtvb4, resistencia;
    private String colorBanda1, colorBanda2, colorBanda3, colorBanda4, strresistencia;
    private Spinner colorSpinner1, colorSpinner2, colorSpinner3, colorSpinner4;
    private Button btnCalcular;
    private String[] colores, colorValores;
    private Banda b1, b2, b3, b4;
    private  Resistencia r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resistencia);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


            colorSpinner1 = findViewById(R.id.spinbanda1);
            colorSpinner2 = findViewById(R.id.spinbanda2);
            colorSpinner3 = findViewById(R.id.spinbanda3);
            colorSpinner4 = findViewById(R.id.spinbanda4);

            txtvb1 = findViewById(R.id.valorbanda1);
            txtvb2 = findViewById(R.id.valorbanda2);
            txtvb3 = findViewById(R.id.valorbanda3);
            txtvb4 = findViewById(R.id.Valorbanda4);
            resistencia= findViewById(R.id.resistencia);

            btnCalcular = findViewById(R.id.calcular);

            colores = new String[]{
                    "oro",
                    "plata",
                    "negro",
                    "marron",
                    "rojo",
                    "naranja",
                    "amarillo",
                    "verde",
                    "azul",
                    "violeta",
                    "gris",
                    "blanco"
            };

            colorValores = new String[]{
                    "#C0C0C0",
                    "#FFD700",
                    "#000000",
                    "#964B00",
                    "#FF0000",
                    "#FFA500",
                    "#FFFF00",
                    "#008000",
                    "#0000FF",
                    "#800080",
                    "#808080",
                    "#FFFFFF"
            };

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_colores, colores) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView textView = view.findViewById(R.id.spinnercolor);
                    textView.setTextColor(Color.parseColor(colorValores[position]));
                    textView.setBackgroundColor(Color.parseColor(colorValores[position]));
                    return view;
                }

                @Override
                public View getDropDownView(int position, View convertView, ViewGroup parent) {
                    View view = super.getDropDownView(position, convertView, parent);
                    TextView textView = view.findViewById(R.id.spinnercolor);
                    textView.setTextColor(Color.parseColor(colorValores[position]));
                    textView.setBackgroundColor(Color.parseColor(colorValores[position]));
                    return view;
                }
            };

            for (Spinner spinner : Arrays.asList(colorSpinner1, colorSpinner2, colorSpinner3, colorSpinner4)) {
                spinner.setAdapter(adapter);
            }

            btnCalcular.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    calcular();
                }
            });



    }

    public void calcular() {
        try {
            colorBanda1 = colores[colorSpinner1.getSelectedItemPosition()];
            colorBanda2 = colores[colorSpinner2.getSelectedItemPosition()];
            colorBanda3 = colores[colorSpinner3.getSelectedItemPosition()];
            colorBanda4 = colores[colorSpinner4.getSelectedItemPosition()];

            b1 = new Banda(colorBanda1, 1);
            if(b1.getValor()!=-1) {

                txtvb1.setText(String.valueOf(Math.round(b1.getValor())));
            }
            b2 = new Banda(colorBanda2, 2);
            if(b2.getValor()!=-1){
                txtvb2.setText(String.valueOf(Math.round(b2.getValor())));
            }
            b3 = new Banda(colorBanda3, 3);
            if(b3.getValor()!=-1) {
                txtvb3.setText(String.valueOf(b3.getValor()));
            }
            b4 = new Banda(colorBanda4, 4);

            r = new Resistencia(b1,b2,b3,b4);
            resistencia.setText("resistencia: " + String.valueOf(r.getResistencia()) + "Ω");

            txtvb4.setText("tolerancia:" + String.valueOf(r.getTolerancia()) + "Ω"
            +"min: " + r.getTolMin() + "Ω  Max: " + r.getTolMax()+ "Ω");


        } catch (Exception e) {
            Toast.makeText(this, "  "+ e +" ", Toast.LENGTH_SHORT).show();

        }
    }
}