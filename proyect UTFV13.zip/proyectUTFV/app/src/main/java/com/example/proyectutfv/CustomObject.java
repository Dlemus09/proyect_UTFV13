package com.example.proyectutfv;

public class CustomObject {
    private String titulo;
    private int imagenid;

    public CustomObject(String titulo, int imagenid) {
        this.titulo = titulo;
        this.imagenid = imagenid;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getImagenid() {
        return imagenid;
}
}