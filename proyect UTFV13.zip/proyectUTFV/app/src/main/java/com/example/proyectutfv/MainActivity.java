package com.example.proyectutfv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listaMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaMain = findViewById(R.id.listMain);
        listaMain.setAdapter(creaAdaptador());

        listaMain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((CustomObject) parent.getItemAtPosition(position)).getTitulo();

                Intent intent;
                switch (selectedItem) {
                    case "HERRAMIENTAS":
                        intent = new Intent(MainActivity.this, CuatriUnoActivity.class);
                        startActivity(intent);
                        break;
                    case "MAPA":
                        intent = new Intent(MainActivity.this, Mapa.class);
                        startActivity(intent);
                        break;
                    case "NOTAS":
                        intent = new Intent(MainActivity.this, NotasActivity.class);
                        startActivity(intent);
                        break;


                    default:
                        Toast.makeText(MainActivity.this, "En construcción", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
   });
}

    public CustomAdapter creaAdaptador() {
        // Lista de items
        String[] listaparaMain = {
                "MAPA",
                "HERRAMIENTAS",
                "CALIFICACIONES",
                "HORARIOS",
                "NOTAS",
                "FAVORITOS"
        };

        // Lista de imágenes
        int[] imageArray = {
                R.drawable.dragonmapa1,
                R.drawable.dragonherramienta,
                R.drawable.dragoncalificaciones,
                R.drawable.dragonhorario,
                R.drawable.dragonotas,
                R.drawable.dragonfavoritos
        };

        List<CustomObject> objetosVista = new ArrayList<>();
        for (int i = 0; i < listaparaMain.length; i++) {
            objetosVista.add(new CustomObject(listaparaMain[i], imageArray[i]));
        }


        return new CustomAdapter(this, objetosVista);
    }
}


