package com.example.proyectutfv;

public class Resistencia {
    private int resistencia;
    private  double tolerancia;
    private  double tolMin;
    private  double tolMax;

    Resistencia(Banda b1, Banda b2, Banda b3, Banda b4){

        calcularRes(b1,b2,b3);
        calcularTolerancia(b4);
    }

    private void calcularRes(Banda b1, Banda b2, Banda b3){
        if(b1.getValor() !=-1 && b2.getValor() !=-1 && b3.getValor() !=-1) {
            int val1=(int) b1.getValor();
            int val2=(int) b2.getValor();
            String stringsuma = String.valueOf(val1) + String.valueOf(val2);
            int suma = Integer.parseInt(stringsuma);
            resistencia = (int) (suma * b3.getValor());
        }
    }

    public void calcularTolerancia(Banda b4){
        String color = b4.getColor();
        double valor;
        switch (color){
            case "negro": valor= 0.2;
                break;
            case "marron": valor= 0.01;
                break;
            case "rojo": valor= 0.02;
                break;
            case "naranja": valor= 0.03;
                break;
            case "amarrilo": valor= 0.04;
                break;
            case "verde": valor= 0.005;
                break;
            case "azul": valor= 0.025;
                break;
            case "violeta": valor= 0.010;
                break;
            case "gris": valor= 0.0005;
                break;
            case "oro": valor=.05;
                break;
            case "plata": valor=0.1;
                break;
            default: valor=-1;
                break;
        }
        if(valor!=-1) {
            tolerancia = resistencia * valor;
            tolMin= resistencia-tolerancia;
            tolMax= resistencia+tolerancia;
        }else{ tolerancia=-1;
                tolMin=-1;
                tolMax=-1;
        }
    }

    public int getResistencia() {
        return resistencia;
    }

    public double getTolerancia() {
        return tolerancia;
    }

    public double getTolMax() {
        return tolMax;
    }

    public double getTolMin() {
        return tolMin;
    }
}
