package com.example.proyectutfv;

public class Banda{

    private String color;
    private int posicion;
    private double valor;

    Banda(String color, int posicion ){
        this.color= color;
        this.posicion=posicion;
        if(posicion<4){
            setValor();
        } else if (posicion==4) {
            valor=-1;
        }
    }

    public void setValor() {
        switch (posicion){
            case 1:
            case 2:
                switch (color){
                    case "negro": valor= 0;
                        break;
                    case "marron": valor= 1;
                        break;
                    case "rojo": valor= 2;
                        break;
                    case "naranja": valor= 3;
                        break;
                    case "amarrillo": valor= 4;
                        break;
                    case "verde": valor= 5;
                        break;
                    case "azul": valor= 6;
                        break;
                    case "violeta": valor= 7;
                        break;
                    case "gris": valor= 8;
                        break;
                    case "blanco": valor= 9;
                        break;
                    default: valor=-1;
                        break;
                }
                break;
            case 3:
                switch (color) {
                    case "negro":
                        valor = 1;
                        break;
                    case "marron":
                        valor = 10;
                        break;
                    case "rojo":
                        valor = 100;
                        break;
                    case "naranja":
                        valor = 1000;
                        break;
                    case "amarrillo":
                        valor = 10000;
                        break;
                    case "verde":
                        valor = 100000;
                        break;
                    case "azul":
                        valor = 1000000;
                        break;
                    case "violeta":
                        valor = 10000000;
                        break;
                    case "gris":
                        valor = 100000000;
                        break;
                    case "blanco":
                        valor = 1000000000;
                        break;
                    case "oro":
                        valor = .1;
                        break;
                    case "plata":
                        valor = .01;
                        break;
                    default:
                        valor = -1;
                        break;
                }
                break;
            default: valor=-1;
                break;
        }
    }

    public double getValor() {
        return valor;
    }
    public String getColor() {
        return color;
    }
}